﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace ADO2
{
    class Program
    {
        static string conString = Properties.Settings.Default.conString;
        static void Main(string[] args)
        {


            try
            {
                Console.WriteLine("Before Modification");
                DisplayData();
                // InsertData();
                Console.WriteLine("After the modification");
                DisplayData();
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }

        }

        private static void InsertData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                string insertstring = @"Select * from Employees";
                using (SqlCommand cmd = new SqlCommand(insertstring, con))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    SqlCommandBuilder cb = new SqlCommandBuilder(da);
                    DataRow dr = ds.Tables[0].NewRow();
                    dr["FirstName"] = "Harika";
                    dr["LastName"] = "nallagatla";
                    DataTable dt = ds.Tables[0];
                    dt.Rows.Add(dr);
                    da.Update(ds);
                }
            }
        }

        private static void DisplayData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                string displayString = @"select * from Employees;Select * from Categories";
                using (SqlCommand cmd = new SqlCommand(displayString, con))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        Console.WriteLine(dr["FirstName"]);

                    }
                    foreach (DataRow dr in ds.Tables[1].Rows)
                    {
                        Console.WriteLine(dr["CategoryName"]);

                    }
                    Console.ReadLine();
                }
            }
        }
    }
}
