﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO.net1
{
    class ADO1
    {
        /**********************************************************************
         Implement the main method
         *****************************************************************************************/


        //1st way of wiritng

        // SqlConnection con = new SqlConnection();
        //con.ConnectionString =@"Server=INCHCMPC11363;Database=assignmentDatabase;Trusted_Connection=True;";
        //con.Open();
        //Console.WriteLine($"{con.State}");

        //Console.WriteLine("Press any key to close the connection...");
        //Console.ReadLine();
        //con.Close();
        //Console.WriteLine($"{con.State}");
        //Console.ReadLine();


        /*2nd way of doing*/

        //string conString = @"Server=INCHCMPC11363;Database=assignmentDatabase;Trusted_Connection=True;";
        //SqlConnection con = new SqlConnection(conString);
        //con.Open();

        //SqlCommand cmd = new SqlCommand();
        //cmd.Connection = con;
        //cmd.CommandText = @"Select * from customers";
        //cmd.CommandType = System.Data.CommandType.Text;

        //SqlDataReader reader = cmd.ExecuteReader();

        //while (reader.Read())
        //{
        //    Console.WriteLine($"the customer id:{reader[0]}| FirstName:{reader[1]}");

        //}

        //con.Close();
        //cmd.Dispose();
        //con.Dispose();
        //Console.ReadLine();

    }
}
